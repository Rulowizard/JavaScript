// from data.js
var tableData = data;

// YOUR CODE HERE!

var tbody = d3.select("tbody");

tableData.forEach(function(UFO){
    var row =tbody.append("tr");
    //row.append("td").text()
    
    
    Object.entries(UFO).forEach(function([key,value]){
        var cell= tbody.append("td");
        cell.text(value);
    })
});

var filter_btn = d3.select("#filter-btn");


filter_btn.on("click", function(){
    d3.event.preventDefault();
    var fecha = d3.select("#datetime").property("value");
    console.log(fecha);
    
    var filteredData = tableData.filter(data=>data.datetime === fecha);
    
    console.log(filteredData);
    tbody.html("");
    
    filteredData.forEach(function(UFO){
        
        
        
        
       var row = tbody.append("tr");
        
        Object.entries(UFO).forEach(function([key,value]){
            var cell= tbody.append("td");
            cell.text(value);
        })
        
        
        
    });
    
    
    
    
});





